#!/bin/bash

#########################
# Global Parameters
######################### 

num_epochs=500
model_lr=0.00001

# DONT CHANGE ANYTHING AFTER HERE

#########################
# Experiment 1 - 3 Poissonian - DnCNN
######################### 


experiment_name='3_Poissonian'
num_experments=\[3,0\]
network_type="DnCNN"
model_lr=0.00001

python3 Supervised_Learning.py $num_epochs $model_lr $num_experments $network_type $experiment_name


#########################
# Experiment 2 - 3 Poissonian - xDnCNN
######################### 
model_lr=0.001


experiment_name='3_Poissonian'
num_experments=\[3,0\]
network_type="xDnCNN"
python3 Supervised_Learning.py $num_epochs $model_lr $num_experments $network_type $experiment_name


experiment_name='3_Poissonian'
num_experments=\[3,0\]
network_type="DnCNN"
python3 Supervised_Learning.py $num_epochs $model_lr $num_experments $network_type $experiment_name


#########################
# Experiment 3 - Gaussian - DnCNN
######################### 


experiment_name='3_Gaussian'
num_experments=\[0,3\]
network_type="DnCNN"
python3 Supervised_Learning.py $num_epochs $model_lr $num_experments $network_type $experiment_name

#########################
# Experiment 4 - Gaussian - xDnCNN
######################### 


experiment_name='3_Gaussian'
num_experments=\[0,3\]
network_type="xDnCNN"
python3 Supervised_Learning.py $num_epochs $model_lr $num_experments $network_type $experiment_name


#########################
# Experiment 5 - Poissonian Gaussian - DnCNN
######################### 


experiment_name='3_Poissonian_3_Gaussian'
num_experments=\[3,3\]
network_type="DnCNN"
python3 Supervised_Learning.py $num_epochs $model_lr $num_experments $network_type $experiment_name

#########################
# Experiment 4 - Poissonian Gaussian - xDnCNN
######################### 


experiment_name='3_Poissonian_3_Gaussian'
num_experments=\[3,3\]
network_type="xDnCNN"
python3 Supervised_Learning.py $num_epochs $model_lr $num_experments $network_type $experiment_name
