import torch
import torch.nn as nn

from torch.utils.data.dataset import Dataset
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from torchvision import transforms
from PIL import Image
from random import sample,seed, shuffle
from skimage.measure import compare_ssim, compare_psnr
import time
import numpy as np
import os
import sys

from Generate_Tasks import *
from Network import *

Experiment_Names=['3_Poissonian','3_Gaussian','3_Poissonian_3_Gaussian']
Network_Types = ['DnCNN','xDnCNN']

experiment_name=Experiment_Names[0]
network_type=Network_Types[0]

def get_best_model(experiment_name, network_type):

    save_folder = '../Results_Folder/'

    #Experiment_Names = ['3_Gaussian','3_Poissonian', '3_Poissonian_3_Gaussian']

    #Network_Type = ['DnCNN','xDnCNN']

    Experment_Folder = save_folder  + experiment_name + '_' + network_type + '/Meta_Performance/'

    STEP = 500

    PSNR_Path = Experment_Folder + 'PSNR/PSNR_Step_' + str(STEP)

    P = torch.load(PSNR_Path)[2,:]

    INDEX = P.argmax().item()+1

    State_Dict_path  = Experment_Folder + 'State_Dicts/State_Dict_Step_' + str(INDEX)
    
    return State_Dict_path


class Reptile_FT():
   
    def __init__(self,
                 model_lr=1e-3, model_weight_decay=1e-5, 
                 num_fine_tune_epochs=500, batch_size=10,
                 datasets_path='../Dataset/',experiment_name='', save_folder='',network_type='DnCNN'
                ):
                    
        self.network_type=network_type
        
        self.datasets_path=datasets_path
        self.experiment_name=experiment_name
        self.save_folder=save_folder
        
        self.model_lr = model_lr
        self.model_weight_decay = model_weight_decay
       
        self.batch_size=batch_size
        
        State_Dict_path=get_best_model(self.experiment_name, self.network_type)
        
        if self.network_type=='DnCNN':
            self.model=DnCNN(image_channels=3)
        else: 
            self.model=xDnCNN(image_channels=3)
        
        self.optimizer = torch.optim.SGD(params=self.model.parameters(),lr=self.model_lr, weight_decay=self.model_weight_decay,
                                              nesterov=True,momentum=0.8)
        #self.optimizer = torch.optim.Adam(params=self.model.parameters(),lr=self.model_lr, weight_decay=self.model_weight_decay)
            
        self.model.to(device)
        self.model.load_state_dict(torch.load(State_Dict_path))

        self.crop_n=10
        self.crop_size=55
        self.crop_image=True
        
        self.datasets_path=datasets_path
        self.experiment_name=experiment_name
        self.save_folder=save_folder
        
        self.FT_Losses = torch.zeros(self.num_fine_tune_epochs)
        
        self.FT_PSNR_out = torch.zeros([3,self.num_fine_tune_epochs])
        self.FT_SSIM_out = torch.zeros([3,self.num_fine_tune_epochs]) # ssim computed by the model
        
        self.VAL_PSNR_out = torch.zeros([3,self.num_fine_tune_epochs])
        self.VAL_SSIM_out = torch.zeros([3,self.num_fine_tune_epochs]) # ssim computed by the model
        
        
        self.training_times = torch.zeros(self.num_fine_tune_epochs)
        
        
    
    #def FT_and_TEST(self):
        
        
        
        
self=Reptile_FT(experiment_name=Experiment_Names[0],network_type="DnCNN")







