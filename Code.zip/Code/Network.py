import torch
import torch.nn as nn
import torch.nn.init as init
import numpy as np

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class DnCNN(nn.Module):
    def __init__(self, depth=13, n_channels=32, image_channels=1, use_bnorm=True, kernel_size=3):
        super(DnCNN, self).__init__()
        kernel_size = 3
        padding = 1
        layers = []
        if image_channels==1:
            depth=13
        elif image_channels==3:
            depth=13
        layers.append(nn.Conv2d(in_channels=image_channels, out_channels=n_channels, kernel_size=kernel_size, padding=padding, bias=True))
        layers.append(nn.ReLU(inplace=True))
        for _ in range(depth-2):
            layers.append(nn.Conv2d(in_channels=n_channels, out_channels=n_channels, kernel_size=kernel_size, padding=padding, bias=False))
            layers.append(nn.BatchNorm2d(n_channels, eps=0.0001, momentum = 0.95))
            layers.append(nn.ReLU(inplace=True))
        layers.append(nn.Conv2d(in_channels=n_channels, out_channels=image_channels, kernel_size=kernel_size, padding=padding, bias=False))
        self.dncnn = nn.Sequential(*layers)
        self._initialize_weights()

    def forward(self, x):
        y = x
        out = self.dncnn(x.to(device))
        return y.to(device)-out

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                init.orthogonal_(m.weight)
                #nit.xavier_normal_(m.weight)
                #print('init weight')
                if m.bias is not None:
                    #init.xavier_normal_(m.bias)
                    init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                init.constant_(m.weight, 1)
                init.constant_(m.bias, 0)
                #init.xavier_normal_(m.weight)
                #init.xavier_normal_(m.bias)
    def get_num_params(self):
        modules=list(self.parameters())
        num_params=0
        for mod in modules:
            num_params+= np.prod(list(mod.shape))
        return num_params
    
    
    
    
    
    
    
    
    
    
    
class Gaussian(nn.Module):
    def forward(self,input):
        return torch.exp(-torch.mul(input,input))

class Modulecell(nn.Module):
    def __init__(self,in_channels=1,out_channels=64,kernel_size=3,skernel_size=9):
        super(Modulecell,self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(in_channels,out_channels,kernel_size=kernel_size,padding=((kernel_size-1)//2)))
        self.module = nn.Sequential(
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
            nn.Conv2d(out_channels,out_channels,kernel_size=skernel_size,stride=1,padding=((skernel_size-1)//2),groups=out_channels),
            nn.BatchNorm2d(out_channels),
            Gaussian())
    def forward(self,x):
        x1 = self.features(x)
        x2 = self.module(x1)
        x = torch.mul(x1,x2)
        return x

class xDnCNN(nn.Module):
    def __init__(self,channels=32, image_channels=3):
        super(xDnCNN,self).__init__()
        self.md1 = nn.Sequential(
            Modulecell(in_channels=image_channels,out_channels=channels,kernel_size=3))
        self.md2 = nn.Sequential(
            nn.BatchNorm2d(channels),
            Modulecell(in_channels=channels,out_channels=channels,kernel_size=3))
        self.md3 = nn.Sequential(
            nn.BatchNorm2d(channels),
            Modulecell(in_channels=channels,out_channels=channels,kernel_size=3))
        self.md4 = nn.Sequential(
            nn.BatchNorm2d(channels),
            Modulecell(in_channels=channels,out_channels=channels,kernel_size=3))
        self.md5 = nn.Sequential(
            nn.BatchNorm2d(channels),
            Modulecell(in_channels=channels,out_channels=channels,kernel_size=3))
        self.md6 = nn.Sequential(
            nn.BatchNorm2d(channels),
            Modulecell(in_channels=channels,out_channels=channels,kernel_size=3))
        self.md7 = nn.Sequential(
            nn.BatchNorm2d(channels),
            Modulecell(in_channels=channels,out_channels=channels,kernel_size=3))
        self.md8 = nn.Sequential(
            nn.BatchNorm2d(channels),
            Modulecell(in_channels=channels,out_channels=channels,kernel_size=3))
        self.joints = nn.Conv2d(channels,image_channels,kernel_size=3,padding=1)
        #print('xDnCNN')

    def forward(self,x):
        
        x = self.md1(x.to(device))
        x = self.md2(x)
        x = self.md3(x)
        x = self.md4(x)
        x = self.md5(x)
        x = self.md6(x)
        x = self.md7(x)
        x = self.md8(x)
        x = self.joints(x)
        return x

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                init.orthogonal_(m.weight)
                #print('init weight')
                if m.bias is not None:
                    init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                init.constant_(m.weight, 1)
                init.constant_(m.bias, 0)


