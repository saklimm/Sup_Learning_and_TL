import torch
from torch.utils.data.dataset import Dataset
import torch.nn as nn
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from torchvision import transforms
from PIL import Image
from random import sample
import os
from Generate_Tasks import *
from Network import *
import sys



from skimage.measure import compare_ssim, compare_psnr

import time

import numpy as np

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")



class Fine_Tuning():
   
    def __init__(self,
                 model_lr=1e-3, model_weight_decay=1e-5, 
                 num_fine_tune_epochs=500, batch_size=1,
                 datasets_path='../Dataset/',experiment_name='', save_folder='',network_type='DnCNN',
                 save_every_step=10, experiment_folder=''
                ):
                    
        self.network_type=network_type
        
        self.datasets_path=datasets_path
        self.experiment_name=experiment_name
        self.save_folder=save_folder
        self.save_every_step=save_every_step
        
        self.model_lr = model_lr
        self.model_weight_decay = model_weight_decay
       
        self.batch_size = batch_size
        self.num_fine_tune_epochs=num_fine_tune_epochs
        
        self.datasets_path=datasets_path
        self.experiment_name=experiment_name
        self.save_folder=save_folder
        self.experiment_folder=experiment_folder
        
        
        
        State_Dict_path=self.get_best_model()
        
        if self.network_type=='DnCNN':
            self.model=DnCNN(image_channels=3)
        else: 
            self.model=xDnCNN(image_channels=3)
        
        #self.optimizer = torch.optim.SGD(params=self.model.parameters(),lr=self.model_lr, weight_decay=self.model_weight_decay,
        #                                      nesterov=True,momentum=0.8)
        self.optimizer = torch.optim.Adam(params=self.model.parameters(),lr=self.model_lr, weight_decay=self.model_weight_decay)
            
        self.model.to(device)
        self.model.load_state_dict(torch.load(State_Dict_path))

        self.crop_n=80
        self.crop_size=55
        self.crop_image=True
        

        self.FT_Losses = torch.zeros(self.num_fine_tune_epochs)
        
        self.FT_PSNR_out = torch.zeros([3,self.num_fine_tune_epochs])
        self.FT_SSIM_out = torch.zeros([3,self.num_fine_tune_epochs]) # ssim computed by the model
        
        self.VAL_PSNR_out = torch.zeros([3,self.num_fine_tune_epochs])
        self.VAL_SSIM_out = torch.zeros([3,self.num_fine_tune_epochs]) # ssim computed by the model
        
        
        self.training_times = torch.zeros(self.num_fine_tune_epochs)
    
    

    def get_best_model(self ):
    
        
    
        STEP = 500
    
        PSNR_Path = self.experiment_folder + 'Training_Results/' +  'PSNR/PSNR_Step_' + str(STEP)
    
        P = torch.load(PSNR_Path)[2,:]
    
        INDEX = P.argmax().item()+1
    
        State_Dict_path  = self.experiment_folder + 'Training_Results/'  + 'State_Dicts/State_Dict_Step_' + str(INDEX)
        
        return State_Dict_path
    
    def one_FT_epoch(self,FT_LOADER,step):
        
        epoch_loss=0
        #   noisy_image,truth =iter(FT_LOADER).next()
        for noisy_image,truth in FT_LOADER:
                batch_loss=0
                
                noisy_image = noisy_image.reshape(-1,3,self.crop_size,self.crop_size)
                truth = truth.reshape(-1,3,self.crop_size,self.crop_size)
                denoised_imgs = self.model.forward(noisy_image)
                batch_loss +=  nn.functional.mse_loss( denoised_imgs.to(device),truth.to(device) )
                self.optimizer.zero_grad()
                batch_loss.backward()
                self.optimizer.step()
                with torch.no_grad():
                    #print(batch_loss.item())
                    epoch_loss+=batch_loss.item()
        
        self.FT_Losses[step]=epoch_loss
        
        if (step+1)% self.save_every_step ==0:
        
            PSNR_epoch_out = torch.Tensor()
            SSIM_epoch_out = torch.Tensor()
                
            with torch.no_grad():
                for noisy_image,truth in FT_LOADER:
                    noisy_image = noisy_image.reshape(-1,3,self.crop_size,self.crop_size)
                    truth = truth.reshape(-1,3,self.crop_size,self.crop_size)
                    denoised_imgs = self.model.forward(noisy_image)
                    
                    img_out = DENORMalize(denoised_imgs, 0.0, 255.0).cpu().detach().numpy().astype('uint8').transpose((0,2,3,1))
                    img_GT = DENORMalize(truth, 0.0, 255.0).cpu().detach().numpy().astype('uint8').transpose((0,2,3,1))
                            
                    psnr_out = torch.Tensor( [compare_psnr(img_out, img_GT)] )
                    ssim_out = torch.Tensor( [ compare_ssim(img_out, img_GT,multichannel=True)  ] )
    
                    PSNR_epoch_out = torch.cat([PSNR_epoch_out,psnr_out])
                    SSIM_epoch_out = torch.cat([SSIM_epoch_out,ssim_out])
                
                self.FT_PSNR_out[:,step]=torch.Tensor([PSNR_epoch_out.max().item(),PSNR_epoch_out.min().item(),PSNR_epoch_out.mean().item()])
                self.FT_SSIM_out[:,step]=torch.Tensor([SSIM_epoch_out.max().item(),SSIM_epoch_out.min().item(),SSIM_epoch_out.mean().item()])
                
                print("Current PSNR - FT SET: ", PSNR_epoch_out.mean().item())
                print("Current SSIM - FT SET: ", SSIM_epoch_out.mean().item())
                
    def one_Val_epoch(self,TEST_LOADER,step):
        PSNR_epoch_out = torch.Tensor()
        SSIM_epoch_out = torch.Tensor()
            
        with torch.no_grad():
            for noisy_image,truth in TEST_LOADER:
                
                noisy_image = noisy_image.reshape(-1,3,self.crop_size,self.crop_size)
                truth = truth.reshape(-1,3,self.crop_size,self.crop_size)
                
                denoised_imgs = self.model.forward(noisy_image)
                
                img_out = DENORMalize(denoised_imgs, 0.0, 255.0).cpu().detach().numpy().astype('uint8').transpose((0,2,3,1))
                img_GT = DENORMalize(truth, 0.0, 255.0).cpu().detach().numpy().astype('uint8').transpose((0,2,3,1))
                                
                #img_GT=DENORMalize(img_GT, 0.0, 255.0).astype(np.uint8)
                #img_out=DENORMalize(img_out, 0.0, 255.0).astype(np.uint8)
    
                psnr_out = torch.Tensor( [compare_psnr(img_out, img_GT)] )
                ssim_out = torch.Tensor( [ compare_ssim(img_out, img_GT,multichannel=True)  ] )

                PSNR_epoch_out = torch.cat([PSNR_epoch_out,psnr_out])
                SSIM_epoch_out = torch.cat([SSIM_epoch_out,ssim_out])
            
            self.VAL_PSNR_out[:,step]=torch.Tensor([PSNR_epoch_out.max().item(),PSNR_epoch_out.min().item(),PSNR_epoch_out.mean().item()])
            self.VAL_SSIM_out[:,step]=torch.Tensor([SSIM_epoch_out.max().item(),SSIM_epoch_out.min().item(),SSIM_epoch_out.mean().item()])
            
            print("Current PSNR - TEST SET: ", PSNR_epoch_out.mean().item())
            print("Current SSIM - TEST SET: ", SSIM_epoch_out.mean().item())
            
    def Fine_Tune_Model(self):
    
    # =============================================================================
    #     fine tuning
    # =============================================================================

        FT_LOADER= SSID_FT_LOADER(batch_size=self.batch_size).loader
        TEST_LOADER= SSID_TEST_LOADER(crop_n=80).loader
        
        for step in range(self.num_fine_tune_epochs):
            
            print('FT Epoch: ',step+1, '// ',self.num_fine_tune_epochs)
            self.one_FT_epoch(FT_LOADER,step)
            if (step+1)% self.save_every_step ==0:
                self.one_Val_epoch(TEST_LOADER,step)
              
                torch.save(self.FT_Losses, self.save_folder + '/Losses/Loss_Step_'+str(step+1))
    
                torch.save(self.FT_PSNR_out, self.save_folder + '/PSNR/FT_PSNR_Step_'+str(step+1))
                torch.save(self.VAL_PSNR_out, self.save_folder + '/PSNR/VAL_PSNR_Step_'+str(step+1))
                
     
                torch.save(self.FT_SSIM_out, self.save_folder + '/SSIM/FT_SSIM_Step_'+str(step+1))
                torch.save(self.VAL_SSIM_out, self.save_folder + '/SSIM/VAL_SSIM_Step_'+str(step+1))
                
                torch.save(self.model.state_dict(),self.save_folder+ '/State_Dicts/State_Dict_Step'+str(step+1) )


datasets_path = '../BSDS500/'
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    


EXPERIMENT_NAME= sys.argv[1]
NETWORK_TYPE=  sys.argv[2]

NUM_TRAINING_EPOCHS = int(sys.argv[3])
MODEL_LR=  float(sys.argv[4])
FT_LR = float(sys.argv[5])

    
RESULTS_FOLDER= '../Results_Folder/Sup_and_TL_Learning_LR=' + str(MODEL_LR) +'/'
EXPERIMENT_FOLDER= RESULTS_FOLDER+ EXPERIMENT_NAME + '_' + NETWORK_TYPE + '/'

SAVE_FOLDER= EXPERIMENT_FOLDER + 'TRANSFER_LEARNING_FT_LR=' + str(FT_LR)  

if not os.path.exists(SAVE_FOLDER  ):
    os.mkdir(SAVE_FOLDER )

if not os.path.exists(SAVE_FOLDER + '/Losses'  ):
    os.mkdir(SAVE_FOLDER + '/Losses' )

if not os.path.exists(SAVE_FOLDER + '/PSNR'  ):
    os.mkdir(SAVE_FOLDER + '/PSNR' )
    
if not os.path.exists(SAVE_FOLDER + '/SSIM'  ):
    os.mkdir(SAVE_FOLDER + '/SSIM' )
    
if not os.path.exists(SAVE_FOLDER + '/State_Dicts'  ):
    os.mkdir(SAVE_FOLDER + '/State_Dicts' )




FT=Fine_Tuning(experiment_name=EXPERIMENT_NAME,network_type=NETWORK_TYPE, experiment_folder=EXPERIMENT_FOLDER,model_lr=FT_LR,
               save_folder=SAVE_FOLDER)
FT.Fine_Tune_Model()


       
            
            