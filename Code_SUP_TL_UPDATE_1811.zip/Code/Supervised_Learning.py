import torch
from torch.utils.data.dataset import Dataset
import torch.nn as nn
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from torchvision import transforms
from PIL import Image
from random import sample
import os
from Generate_Tasks import *
from Network import *
import sys



from skimage.measure import compare_ssim, compare_psnr

import time

import numpy as np

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
datasets_path = '../Dataset/'
save_folder = '../Results_Folder/'
    
class Supervised_Learning():
    def __init__(self,
                 
                 train_lr =1e-4,  
                 training_epochs=500, training_batch_size=25,
                 num_experiments=[3,3],
                 datasets_path=datasets_path,save_folder=save_folder,results_folder='',
                 network_type='DnCNN', save_every_step=10,EXPERIMENT_NAME=''):

         
        self.training_epochs=training_epochs
        self.training_batch_size=training_batch_size
        self.train_lr =train_lr
        
        self.EXPERIMENT_NAME=EXPERIMENT_NAME
        self.num_experiments=num_experiments
        self.save_every_step=save_every_step
        
        self.datasets_path=datasets_path
        #self.experiment_name = experiment_name
        self.save_folder=save_folder# + self.experiment_name + '/'
        self.results_folder=results_folder
        
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.network_type=network_type
        
        if self.network_type == "DnCNN":
            self.model= DnCNN(image_channels=3)
        else:
            self.model= xDnCNN(image_channels=3)
        
        
        self.model.to(self.device)
        
        self.SL_Loss = torch.zeros([self.training_epochs])
        self.SL_PSNR = torch.zeros([3,self.training_epochs])
        self.SL_SSIM = torch.zeros([3,self.training_epochs])
        self.training_times = torch.zeros(self.training_epochs)
        
        self.crop_size=55
    
    def get_init_noise(self):

        self.PSNR_in = torch.Tensor()
        self.SSIM_in = torch.Tensor() 
        
        train_loader = Supervised_Learning_Loader(self.datasets_path,self.training_batch_size).train_loader
        
        PSNR_in = torch.Tensor()
        SSIM_in = torch.Tensor() 
       
            
        for noisy_image,truth in train_loader:
            noisy_image = noisy_image.reshape(-1,1,self.crop_size,self.crop_size)
            truth = truth.reshape(-1,3,self.crop_size,self.crop_size)

            img_in = noisy_image.squeeze().cpu().detach().numpy()
            img_GT =  truth.reshape(-1,self.crop_size,self.crop_size).numpy()
            
            img_in=DENORMalize(img_in, 0.0, 255.0).astype(np.uint8)
            img_GT=DENORMalize(img_GT, 0.0, 255.0).astype(np.uint8)

            psnr_in = torch.Tensor( [compare_psnr(img_in, img_GT)] )
            ssim_in = torch.Tensor( [compare_ssim(img_in, img_GT,multichannel=True)] )

            PSNR_in = torch.cat([PSNR_in,psnr_in])
            SSIM_in = torch.cat([SSIM_in,ssim_in])
        
        self.PSNR_in = PSNR_in.mean().item()
        self.SSIM_in = SSIM_in.mean().item()
        print('Supervised Learning')
        print('Experiment_Name:', self.EXPERIMENT_NAME + '_'+ self.network_type)
        
        print('Initial PSNR:', PSNR_in.mean().item())
        print('Initial SSIM:', SSIM_in.mean().item())
        
        torch.save(self.PSNR_in, SAVE_FOLDER + '/PSNR/Initial_PSNR' )
        torch.save(self.SSIM_in, SAVE_FOLDER + '/SSIM/Initial_SSIM' )

    
        
    def one_training_epoch(self,train_loader,step):

        PSNR_epoch = torch.Tensor()
        SSIM_epoch= torch.Tensor()
        loss_epoch = 0.0
        
        #optimizer = torch.optim.SGD(params=self.model.parameters(),lr=self.train_lr, weight_decay=self.train_weight_decay,
        #                                      nesterov=True,momentum=0.8)
        
        optimizer = torch.optim.Adam(self.model.parameters(),lr = self.train_lr)

        self.model.train()
        time_start = time.time()
        for noisy_image,truth in train_loader:
            
            noisy_image = noisy_image.reshape(-1,3,self.crop_size,self.crop_size)
            truth = truth.reshape(-1,3,self.crop_size,self.crop_size)
            denoised_imgs = self.model.forward(noisy_image)
                        
            loss = nn.functional.mse_loss( denoised_imgs,truth.to(device) )
                #print(loss.item())
            loss_epoch+= loss.item()
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            del(loss)
        time_epoch = time.time()-time_start    
        self.training_times[step]=time_epoch
        if (step+1)%self.save_every_step==0:
        
            # go through dataset once more to compute performance measures after optimization steps
            with torch.no_grad():
                self.model.eval()
                for noisy_image,truth in train_loader:
                    
                    noisy_image = noisy_image.reshape(-1,3,self.crop_size,self.crop_size)
                    truth = truth.reshape(-1,3,self.crop_size,self.crop_size)
                    denoised_imgs = self.model.forward(noisy_image)
                    
                    img_out = DENORMalize(denoised_imgs, 0.0, 255.0).cpu().detach().numpy().astype('uint8').transpose((0,2,3,1))
                    img_GT =  DENORMalize(truth, 0.0, 255.0).cpu().detach().numpy().astype('uint8').transpose((0,2,3,1))
                    
                    #for k in range(img_out.shape[0]):
                    
                    psnr_out = torch.Tensor( [compare_psnr(img_out, img_GT)] )
                    ssim_out = torch.Tensor( [compare_ssim(img_out, img_GT,multichannel=True)] )
    
                PSNR_epoch = torch.cat([PSNR_epoch,psnr_out])
                SSIM_epoch = torch.cat([SSIM_epoch,ssim_out])
            
                self.SL_Loss[step] = loss_epoch
                self.SL_PSNR[:,step] = torch.Tensor([PSNR_epoch.max().item(),PSNR_epoch.min().item(),PSNR_epoch.mean().item()])
                self.SL_SSIM[:,step] = torch.Tensor([SSIM_epoch.max().item(),SSIM_epoch.min().item(),SSIM_epoch.mean().item()])
            
        
    def SL_Train(self):
        
        
        train_loader = Supervised_Learning_Loader(self.datasets_path,self.training_batch_size,
                                                  num_experiments=self.num_experiments).train_loader
        #TL_optimizer = torch.optim.Adam(self.model.parameters(),lr=self.train_lr,weight_decay=self.train_weight_decay)
        
        for step in range(self.training_epochs):
            
            print('Training Step ', step +1, ' // ', self.training_epochs )
            
            
            self.one_training_epoch(train_loader,step)
            
            
            if (step+1)%self.save_every_step ==0:
                torch.save(self.SL_Loss, self.save_folder + 'Losses/Loss_Step_'+str(step+1))    
                torch.save(self.SL_PSNR,self.save_folder + 'PSNR/PSNR_Step_'+str(step+1))
                torch.save(self.SL_SSIM,self.save_folder + 'SSIM/SSIM_Step_'+str(step+1))
                torch.save(self.model.state_dict(), self.save_folder+'State_Dicts/State_Dict_Step_' + str(step+1))        
                torch.save(self.training_times, self.save_folder+'State_Dicts/Training_Times_to_Step' + str(step+1)) 
                
                print('###############################')
                
                print('Initial PSNR:', self.PSNR_in)
                print('Current PSNR:', self.SL_PSNR[2,step].item())
                print('Initial SSIM:', self.SSIM_in)
                print('Current SSIM:', self.SL_SSIM[2,step].item())
                print('###############################')
                
                #self.eval_supervised(step)

        
    
#    def eval_supervised(self,step):
#        
#        Experiment_Names  = ['3_Poissonian','3_Gaussian', '3_Poissonian_3_Gaussian']
#        Experiment_Params = [[3,0],[0,3],[3,3] ]
#        
#        
#        for l in range(len(tube_current)):
#        
#            for k in range(len(Experiment_Nums)):
#    #            loader=MAML_Validation_Loader(datasets_path=self.datasets_path,num_tasks=Experiment_Nums[k])
#                val_loader= Tube_Task(datasets_path=self.datasets_path,tube_dose_folder_name=tube_current[k],
#                                            crop_image=True, crop_n=10, crop_size=55).val_loader
#                
#                PSNR_out = torch.Tensor()
#                SSIM_out = torch.Tensor()
#                
#                experiment_path=self.results_folder + Experiment_Names[k] + '/'
#                
#                if not os.path.exists(experiment_path):
#                    os.mkdir(experiment_path)
#                    
#                if not os.path.exists(experiment_path + 'PSNR'):
#                    os.mkdir(experiment_path + 'PSNR')
#                    
#                if not os.path.exists(experiment_path +'SSIM'):
#                    os.mkdir(experiment_path+'SSIM')
#                
#                with torch.no_grad():
#                    for noisy_image,truth in val_loader:
#                        noisy_image = noisy_image.reshape(-1,1,self.crop_size,self.crop_size)
#                        #truth = truth.reshape(-1,1,self.crop_size,self.crop_size)
#                        denoised_imgs = self.model.forward(noisy_image)
#                        
#                        
#                        img_out = denoised_imgs.squeeze().cpu().detach().numpy()
#                        img_GT =  truth.reshape(-1,self.crop_size,self.crop_size).numpy()
#                        
#                        img_out=DENORMalize(img_out, 0.0, 255.0).astype(np.uint8)
#                        img_GT=DENORMalize(img_GT, 0.0, 255.0).astype(np.uint8)
#            
#                        psnr_out = torch.Tensor( [compare_psnr(img_out, img_GT)] )
#                        ssim_out = torch.Tensor( [compare_ssim(img_out, img_GT)] )
#        
#                        PSNR_out = torch.cat([PSNR_out,psnr_out])
#                        SSIM_out = torch.cat([SSIM_out,ssim_out])
#                    
#                    PSNR_stat = torch.Tensor([PSNR_out.max().item(),PSNR_out.min().item(),PSNR_out.mean().item()])
#                    SSIM_stat = torch.Tensor([SSIM_out.max().item(),SSIM_out.min().item(),SSIM_out.mean().item()])
#                    
#                    torch.save(PSNR_stat, experiment_path+'PSNR/PSNR_Step_'+str(step+1))
#                    torch.save(SSIM_stat, experiment_path+'SSIM/SSIM_Step_'+str(step+1))



if __name__ == "__main__":

    datasets_path = '../BSDS500/'
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    

    
    NUM_TRAINING_EPOCHS = int(sys.argv[1])
        
    MODEL_LR = float(sys.argv[2])
    
    if not os.path.exists('../Results_Folder/'):
        os.mkdir('../Results_Folder/')
    
    RESULTS_FOLDER= '../Results_Folder/Sup_and_TL_Learning/'# + str(MODEL_LR) +'/'
    
    if not os.path.exists(RESULTS_FOLDER):
        os.mkdir(RESULTS_FOLDER)
    
    NUM_EXPERIMENTS = list( map(int, sys.argv[3].strip('[]').split(',')) )
    
    NETWORK_TYPE= sys.argv[4]
    
    EXPERIMENT_NAME= sys.argv[5]
    
    EXPERIMENT_FOLDER = RESULTS_FOLDER   + EXPERIMENT_NAME + '_' + NETWORK_TYPE +'/'
    
    SAVE_EVERY_STEP = int(sys.argv[6])
    
    if not os.path.exists(EXPERIMENT_FOLDER):
        os.mkdir(EXPERIMENT_FOLDER)
    
    SAVE_FOLDER = EXPERIMENT_FOLDER + 'Training_Results/'
    
    if not os.path.exists(SAVE_FOLDER):
        os.mkdir(SAVE_FOLDER)
    if not os.path.exists(SAVE_FOLDER + 'PSNR/'):
        os.mkdir(SAVE_FOLDER + 'PSNR/')
    if not os.path.exists(SAVE_FOLDER + 'SSIM/'):
        os.mkdir(SAVE_FOLDER + 'SSIM/')
    if not os.path.exists(SAVE_FOLDER + 'Losses/'):
        os.mkdir(SAVE_FOLDER + 'Losses/')
    if not os.path.exists(SAVE_FOLDER + 'State_Dicts/'):
        os.mkdir(SAVE_FOLDER + 'State_Dicts/')    

    

    SL = Supervised_Learning(
                       train_lr = MODEL_LR, 
                       training_epochs=NUM_TRAINING_EPOCHS, training_batch_size=10, 
                       datasets_path=datasets_path,save_folder=SAVE_FOLDER, results_folder=RESULTS_FOLDER,
                       network_type=NETWORK_TYPE, num_experiments=NUM_EXPERIMENTS,save_every_step=SAVE_EVERY_STEP,EXPERIMENT_NAME=EXPERIMENT_NAME)    
                       # should be changed according to hardware 
                       # how many training_epochs for transfer learning? unsure
                       #FT_epochs = 500, FT_batch_size = 10,
                       #FT_lr =1e-3, FT_weight_decay = 0.005,
                       #k_shot=10, 
    SL.get_init_noise()
    SL.SL_Train()

                                    # TL_state_dict_number should be equal to training_epochs
                                    # so you load the last state dict after traning
                                    # same for FT_state_dict_number - load
                                    # the latest fine_tune_parameters for validation






