
from torch.utils.data.dataset import Dataset
from torch.utils.data import DataLoader
from torchvision import transforms
from PIL import Image
import glob
from torch.utils.data.sampler import SubsetRandomSampler, SequentialSampler
import random
import torch
import numpy as np
import matplotlib.pyplot as plt
from skimage.measure import compare_ssim, compare_psnr
    

dataset_path='../BSDS500/'

def NORMalize(image, MIN_B, MAX_B):
   image = (image - MIN_B) / (MAX_B - MIN_B)
   #image[image>1] = 1.
   #image[image<0] = 0.
   return image

def DENORMalize(image, MIN_B, MAX_B):
    image = image * (MAX_B - MIN_B) + MIN_B
    return image


def data_aug(input_img_, mode=0):
    # data augmentation
    if mode == 0:
        return input_img_
    elif mode == 1:
        return input_img_.flip(2)
    elif mode == 2:
        return input_img_.rot90(1,(1,2))
    elif mode == 3:
        return input_img_.rot90(1,(1,2)).flip(2)
    elif mode == 4:
        return input_img_.rot90(2,(1,2))
    elif mode == 5:
        return input_img_.rot90(2,(1,2)).flip(2)
    elif mode == 6:
        return input_img_.rot90(3,(1,2))
    elif mode == 7:
        return input_img_.rot90(3,(1,2)).flip(2)


def crop(object, index):
    
        transformer = transforms.ToTensor()

        image = transformer(Image.open(object.noisy_imgs[index]))
        truth = transformer(Image.open(object.truth[index]))
        
        #pdb.set_trace()
        #print(idx)

        assert image.shape == truth.shape
        c,h, w = image.shape
        crop_image = torch.zeros( [object.crop_n,c,object.crop_size,object.crop_size] )
        crop_truth = torch.zeros( [object.crop_n,c,object.crop_size,object.crop_size] )

        new_h, new_w = object.crop_size, object.crop_size
        tops = np.floor( np.linspace(0,h-new_h,object.crop_n,endpoint=True))
        lefts = np.floor( np.linspace(0,w-new_w,object.crop_n,endpoint=True))
       
        
        
        for k in range(object.crop_n):
           
            top = int(tops[k])
            left = int(lefts[k])
            input_img_ = image[:,top:top+new_h, left:left+new_w]
            target_img_ = truth[:,top:top+new_h, left:left+new_w]
            
            modeAug=random.randint(0,7)
            crop_image[k] = data_aug( input_img_,modeAug)
            crop_truth[k] = data_aug(target_img_,modeAug)

        return crop_image,crop_truth# crop_image.unsqueeze(1),crop_truth.unsqueeze(1)


def crop_without_aug(object, index):
    
        transformer = transforms.ToTensor()

        image = transformer(Image.open(object.noisy_imgs[index]))
        truth = transformer(Image.open(object.truth[index]))
        
        #pdb.set_trace()
        #print(idx)

        assert image.shape == truth.shape
        c,h, w = image.shape
        crop_image = torch.zeros( [object.crop_n,c,object.crop_size,object.crop_size] )
        crop_truth = torch.zeros( [object.crop_n,c,object.crop_size,object.crop_size] )

        new_h, new_w = object.crop_size, object.crop_size
        tops = np.floor( np.linspace(0,h-new_h,object.crop_n,endpoint=True))
        lefts = np.floor( np.linspace(0,w-new_w,object.crop_n,endpoint=True))
        
        for k in range(object.crop_n):
           
            top = int(tops[k])
            left = int(lefts[k])
            input_img_ = image[:,top:top+new_h, left:left+new_w]
            target_img_ = truth[:,top:top+new_h, left:left+new_w]
            
            crop_image[k] = input_img_
            crop_truth[k] = target_img_

        return crop_image,crop_truth# crop_image.unsqueeze(1),crop_truth.unsqueeze(1)

#
#def crop_SIDD(object, index):
#    
#        transformer = transforms.ToTensor()
#
#        image = transformer(Image.open(object.noisy_imgs[index]))
#        truth = transformer(Image.open(object.truth[index]))
#        
#        #pdb.set_trace()
#        #print(idx)
#
#        assert image.shape == truth.shape
#        c,h, w = image.shape
#        
#        new_h, new_w = object.crop_size, object.crop_size
#        tops = np.array(range(0, h-new_h+1, 38))
#        lefts = np.array(range(0, w-new_w+1, 38))
#        
#        crop_image = torch.zeros( [object.crop_n,c,object.crop_size,object.crop_size] )
#        crop_truth = torch.zeros( [object.crop_n,c,object.crop_size,object.crop_size] )
#
#        new_h, new_w = object.crop_size, object.crop_size
#        tops = np.floor( np.linspace(0,h-new_h,object.crop_n,endpoint=True))
#        lefts = np.floor( np.linspace(0,w-new_w,object.crop_n,endpoint=True))
#        
#        for k in range(object.crop_n):
#           
#            top = int(tops[k])
#            left = int(lefts[k])
#            input_img_ = image[:,top:top+new_h, left:left+new_w]
#            target_img_ = truth[:,top:top+new_h, left:left+new_w]
#            
#            crop_image[k] = input_img_
#            crop_truth[k] = target_img_
#
#        return crop_image,crop_truth


#def crop_patches(object, index):
#    
#    #transformer = transforms.Compose([transforms.ToTensor(),transforms.ToPILImage(),transforms.Resize((3200,4200), interpolation=Image.NEAREST ),transforms.ToTensor()])
#    transformer = transforms.ToTensor()
#
#    image = transformer(Image.open(object.noisy_imgs[index]))
#    truth = transformer(Image.open(object.truth[index]))
#    
#    assert image.shape == truth.shape
#    c,h, w = image.shape
#    
#    crop_image = torch.zeros( [object.crop_n,c,object.crop_size,object.crop_size] )
#    crop_truth = torch.zeros( [object.crop_n,c,object.crop_size,object.crop_size] )
#    
#    (0, h-object.patch_size+1, object.stride)
#    
#    input_patches = []
#    target_patches = []
#    
#    for i in range(0, h-object.crop_size+1, object.stride):
#        for j in range(0, w-object.crop_size+1, object.stride):
#            input_patch = image[:,i:i+object.crop_size, j:j+object.crop_size]
#            target_patch = truth[:,i:i+object.crop_size, j:j+object.crop_size]
#    
#            modeAug=random.randint(0,7)
#            input_patch = data_aug( input_patch,modeAug)
#            target_patch = data_aug(target_patch,modeAug)
#            input_patches.append(input_patch)
#            target_patches.append(target_patch)
#    
#    Z=torch.Tensor(input_patches)
      
class NI_Loader_Poissonian(Dataset):
    # N specifies the noise level 
    
    def __init__(self, dataset_path , N='9', crop_image=False, crop_n=15, crop_size=55):

        self.noisy_imgs = glob.glob(dataset_path+"P"+N+'/' +"*.jpg")
        
        Z = [int(im.split('/P'+N+'/')[-1].split('.jpg')[0]) for im in self.noisy_imgs]
        Z.sort()
        self.noisy_imgs = [dataset_path+"P"+N+'/' + str(i) +'.jpg' for i in Z ]
        
        self.truth = glob.glob(dataset_path+"G0/" +"*.jpg")
        Z = [int(im.split('/G0/')[-1].split('.jpg')[0]) for im in self.truth]
        Z.sort()
        self.truth = [dataset_path+"G0/" + str(i) +'.jpg' for i in Z ]
        
        self.crop_n = crop_n
        self.crop_size = crop_size
        self.crop_image = crop_image

     
    def __getitem__(self, index):
        
        if self.crop_image:
            image,truth = crop(self,index)
        else:
            transformer = transforms.ToTensor()
            image = transformer(Image.open(self.noisy_imgs[index]))
            truth = transformer(Image.open(self.truth[index]))
        
        return image,truth
    
    def __len__(self):
        return len(self.noisy_imgs)

class Poissonian_Task():
    
    def __init__(self,datasets_path ,N='9.5', batch_size=10,crop_image=False, crop_n=15, crop_size=55 ):
        self.datasets_path=datasets_path
        
        self.dataset_train =  NI_Loader_Poissonian(self.datasets_path + 'train/' ,N, crop_image, crop_n, crop_size )
        self.dataset_val =  NI_Loader_Poissonian(self.datasets_path + 'val/',N, crop_image, crop_n, crop_size )

        self.batch_size= batch_size
        self.N=N

        self.images_indices_train = list(range(len(self.dataset_train)))
        self.images_indices_val = list(range(len(self.dataset_val)))
        
        
        self.train_sampler = SubsetRandomSampler(self.images_indices_train)
        self.train_loader = DataLoader(self.dataset_train, batch_size=self.batch_size, sampler=self.train_sampler, num_workers=1)
        

        self.val_sampler = SubsetRandomSampler(self.images_indices_val)
        self.val_loader = DataLoader(self.dataset_val, batch_size=self.batch_size, sampler=self.val_sampler, num_workers=1)

#Task = Poissonian_Task(crop_image=True)

#(d,t) = iter(Task.train_loader).next()
 
class NI_Loader_Gaussian(Dataset):
    # N specifies the noise level 
    
    def __init__(self, datasets_path , sigma_id='15', crop_image=False, crop_n=15, crop_size=55):
        self.datasets_path=datasets_path
        self.noisy_imgs = glob.glob(self.datasets_path+"G"+sigma_id+'/' +"*.jpg")
        
        Z = [int(im.split('/G'+sigma_id+'/')[-1].split('.jpg')[0]) for im in self.noisy_imgs]
        Z.sort()
        self.noisy_imgs = [self.datasets_path+"G"+sigma_id+'/' + str(i) +'.jpg' for i in Z ]
        
        self.truth = glob.glob(self.datasets_path+"G0/" +"*.jpg")
        Z = [int(im.split('/G0/')[-1].split('.jpg')[0]) for im in self.truth]
        Z.sort()
        self.truth = [self.datasets_path+"G0/" + str(i) +'.jpg' for i in Z ]
        
        self.crop_n = crop_n
        self.crop_size = crop_size
        self.crop_image = crop_image

     
    def __getitem__(self, index):
        
        if self.crop_image:
            image,truth = crop(self,index)
        else:
            transformer = transforms.ToTensor()
            image = transformer(Image.open(self.noisy_imgs[index]))
            truth = transformer(Image.open(self.truth[index]))
        
        return image,truth    

    def __len__(self):
        return len(self.noisy_imgs)
    
class Gaussian_Task():
    
    def __init__(self,datasets_path ,sigma_id='15', batch_size=10,crop_image=False, crop_n=15, crop_size=55 ):
        self.datasets_path=datasets_path
        self.dataset_train =  NI_Loader_Gaussian(self.datasets_path + 'train/' ,sigma_id, crop_image, crop_n, crop_size )
        self.dataset_val =  NI_Loader_Gaussian(self.datasets_path + 'val/',sigma_id, crop_image, crop_n, crop_size )

        self.batch_size= batch_size
        self.sigma_id=sigma_id

        # 160 images for meta training, 40 for validaton
        self.images_indices_train = list(range(len(self.dataset_train)))
        self.images_indices_val = list(range(len(self.dataset_val)))
        
        
        self.train_sampler = SubsetRandomSampler(self.images_indices_train)
        self.train_loader = DataLoader(self.dataset_train, batch_size=self.batch_size, sampler=self.train_sampler, num_workers=1)
        

        self.val_sampler = SubsetRandomSampler(self.images_indices_val)
        self.val_loader = DataLoader(self.dataset_val, batch_size=self.batch_size, sampler=self.val_sampler, num_workers=1)


#Task = Gaussian_Task(crop_image=True)

#(d,t) = iter(Task.val_loader).next()

# =============================================================================
# Supervised Learning Loader
# =============================================================================

class Supervised_Learning_Dataset(Dataset):
    
    def get_gaussian_image_paths(self, sigma_id):

        noisy_imgs = glob.glob(self.datasets_path+"train/G"+sigma_id+'/' +"*.jpg")
        
        Z = [int(im.split('/G'+sigma_id+'/')[-1].split('.jpg')[0]) for im in noisy_imgs]
        Z.sort()
        noisy_imgs = [self.datasets_path+"train/G"+sigma_id+'/' + str(i) +'.jpg' for i in Z ]
        
        truth = glob.glob(self.datasets_path+"train/G0/" +"*.jpg")
        Z = [int(im.split('/G0/')[-1].split('.jpg')[0]) for im in truth]
        Z.sort()
        truth = [self.datasets_path+"train/G0/" + str(i) +'.jpg' for i in Z ]
        return noisy_imgs, truth

    def get_poissonian_image_paths(self, N):
        noisy_imgs = glob.glob(self.datasets_path+"train/P"+N+'/' +"*.jpg")
        
        Z = [int(im.split('/P'+N+'/')[-1].split('.jpg')[0]) for im in noisy_imgs]
        Z.sort()
        noisy_imgs = [self.datasets_path+"train/P"+N+'/' + str(i) +'.jpg' for i in Z ]
        
        truth = glob.glob(self.datasets_path+"train/G0/" +"*.jpg")
        Z = [int(im.split('/G0/')[-1].split('.jpg')[0]) for im in truth]
        Z.sort()
        truth = [self.datasets_path+"train/G0/" + str(i) +'.jpg' for i in Z ]
        
        return noisy_imgs, truth

            
    ## get all images from all datasets and put them together
    
    def __init__(self, datasets_path,crop_image=True, crop_n=15, crop_size=55, 
                 num_poi=3, num_gauss=3):
        
        # fetch indices of the meta training set
        self.datasets_path =datasets_path 
        self.crop_image=True
        self.crop_n=15
        self.crop_size=55         
        

                        
        noise_levels_poi = ['9','9.5','10'] 
        var_ids = ['15','25','50']
        
        self.noisy_imgs =[]
        self.truth=[]
        
        IDs = list(range(400))#400
        
        for noise_level in noise_levels_poi[:num_poi]:
            noisy_imgs,truth = self.get_poissonian_image_paths(noise_level)
            self.noisy_imgs += [noisy_imgs[i] for i in IDs]
            self.truth += [truth[i] for i in IDs]
            
        for var in var_ids[:num_gauss]:
            noisy_imgs,truth = self.get_gaussian_image_paths(var)
            self.noisy_imgs += [noisy_imgs[i] for i in IDs]
            self.truth += [truth[i] for i in IDs]

        
               
    def __getitem__(self, index):
            
            if self.crop_image:
                image,truth = crop(self,index)
            else:
                transformer = transforms.ToTensor()
                image = transformer(Image.open(self.noisy_imgs[index]))
                truth = transformer(Image.open(self.truth[index]))
            
            return image,truth


class Supervised_Learning_Loader():
    
    def __init__(self,datasets_path, batch_size=10, num_experiments=[3,3]):
        self.datasets_path=datasets_path
        self.batch_size= batch_size
        self.crop_image=True
        self.crop_n=15
        self.crop_size=55 
        self.num_poi = num_experiments[0]
        self.num_gauss = num_experiments[1]
        self.dataset =  Supervised_Learning_Dataset(self.datasets_path,num_poi=self.num_poi,num_gauss=self.num_gauss )
         
        self.train_sampler = SequentialSampler( list(range( len(self.dataset.noisy_imgs))))
        self.train_loader = DataLoader(self.dataset, batch_size=self.batch_size, sampler=self.train_sampler)


#upervised_Learning_Dataset(datasets_path,3,3)

#LOOD = Supervised_Learning_Loader(datasets_path)
# =============================================================================
# SSID LOADER
# =============================================================================


with open('FT_DATA_GT.txt') as f:
    indices_ft = [line.rstrip('\n') for line in f]
    f.close()

class SSID_FT_DATASET(Dataset):
    # N specifies the noise level 
    
    def __init__(self, crop_image=False, crop_n=225, crop_size=40):

        with open('FT_DATA_NOISY.txt') as f:
            self.noisy_imgs = [line.rstrip('\n') for line in f]
            f.close()
        
        with open('FT_DATA_GT.txt') as f:
            self.truth = [line.rstrip('\n') for line in f]
            f.close()
        
        
        self.crop_n = crop_n
        self.crop_size = crop_size
        self.crop_image = crop_image
        
     
    def __getitem__(self, index):
        
        if self.crop_image:
            image,truth = crop(self,index)
        else:
            transformer = transforms.ToTensor()
            image = transformer(Image.open(self.noisy_imgs[index]))
            truth = transformer(Image.open(self.truth[index]))
        
        return image,truth    

    def __len__(self):
        return len(self.noisy_imgs)


class SSID_TEST_DATASET(Dataset):
    # N specifies the noise level 
    
    def __init__(self, crop_image=False, crop_n=225, crop_size=40):

        with open('TEST_DATA_NOISY.txt') as f:
            self.noisy_imgs = [line.rstrip('\n') for line in f]
            f.close()
        
        with open('TEST_DATA_GT.txt') as f:
            self.truth = [line.rstrip('\n') for line in f]
            f.close()
        
        
        self.crop_n = crop_n
        self.crop_size = crop_size
        self.crop_image = crop_image
        
     
    def __getitem__(self, index):
        
        if self.crop_image:
            image,truth = crop_without_aug(self,index)
        else:
            transformer = transforms.ToTensor()
            image = transformer(Image.open(self.noisy_imgs[index]))
            truth = transformer(Image.open(self.truth[index]))
        
        return image,truth    

    def __len__(self):
        return len(self.noisy_imgs)

  
class SSID_FT_LOADER():
    
    def __init__(self, batch_size=1,crop_image=True, crop_n=225, crop_size=40 ):
        self.crop_size = crop_size
        
        self.dataset =  SSID_FT_DATASET(crop_image=crop_image,crop_n=crop_n, crop_size=crop_size)

        self.batch_size= batch_size
        self.image_indices = list(range(len(self.dataset)))
        
        
        
        self.sampler = SubsetRandomSampler(self.image_indices)
        self.loader = DataLoader(self.dataset, batch_size=self.batch_size, sampler=self.sampler, num_workers=1)

#loader = SSID_FT_LOADER().loader
#d,t = iter(loader).next()
    
class SSID_TEST_LOADER():
    
    def __init__(self, batch_size=1,crop_image=True, crop_n=225, crop_size=40 ):
        self.dataset =  SSID_TEST_DATASET(crop_image=crop_image,crop_n=crop_n, crop_size=crop_size)

        self.batch_size= batch_size
        self.image_indices = list(range(len(self.dataset)))
        
        self.sampler = SubsetRandomSampler(self.image_indices)
        self.loader = DataLoader(self.dataset, batch_size=self.batch_size, sampler=self.sampler)


#loader = SSID_FT_LOADER(crop_n=225).loader
#   
#PSNR_epoch_out = torch.Tensor()
#SSIM_epoch_out = torch.Tensor()
#         
#for noisy_image,truth in loader:
#    
#    noisy_image = noisy_image.reshape(-1,3,40,40)
#    truth = truth.reshape(-1,3,40,40)
#    
#    
#    img_in = DENORMalize(noisy_image, 0.0, 255.0).cpu().detach().numpy().astype('uint8').transpose((0,2,3,1))
#    img_GT = DENORMalize(truth, 0.0, 255.0).cpu().detach().numpy().astype('uint8').transpose((0,2,3,1))
#                    
#    #img_GT=DENORMalize(img_GT, 0.0, 255.0).astype(np.uint8)
#    #img_out=DENORMalize(img_out, 0.0, 255.0).astype(np.uint8)
#
#    psnr_out = torch.Tensor( [compare_psnr(img_in, img_GT)] )
#    ssim_out = torch.Tensor( [ compare_ssim(img_in, img_GT,multichannel=True)  ] )
#
#    PSNR_epoch_out = torch.cat([PSNR_epoch_out,psnr_out])
#    SSIM_epoch_out = torch.cat([SSIM_epoch_out,ssim_out])
#
#VAL_PSNR_out=torch.Tensor([PSNR_epoch_out.max().item(),PSNR_epoch_out.min().item(),PSNR_epoch_out.mean().item()])
#VAL_SSIM_out=torch.Tensor([SSIM_epoch_out.max().item(),SSIM_epoch_out.min().item(),SSIM_epoch_out.mean().item()])
#
#print(VAL_PSNR_out)
#print(VAL_SSIM_out)




