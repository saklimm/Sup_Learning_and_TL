import torch

def get_best_model(experiment_name, network_type):

    save_folder = '../Results_Folder/'

    #Experiment_Names = ['3_Gaussian','3_Poissonian', '3_Poissonian_3_Gaussian']

    #Network_Type = ['DnCNN','xDnCNN']

    Experment_Folder = save_folder + 'Training_Results_' + experiment_name + '_' + network_type + '/'

    STEP = 500

    PSNR_Path = Experment_Folder + 'PSNR/PSNR_Step_' + str(STEP)

    P = torch.load(PSNR_Path)[2,:]

    INDEX = P.argmax().item()+1

    State_Dict_path  = Experment_Folder + 'State_Dicts/State_Dict_Step_' + str(INDEX)
    
    return State_Dict_path

