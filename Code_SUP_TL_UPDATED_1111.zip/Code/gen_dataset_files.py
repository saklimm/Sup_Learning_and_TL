
from torch.utils.data.dataset import Dataset
from torch.utils.data import DataLoader
from torchvision import transforms
from PIL import Image
import glob
from torch.utils.data.sampler import SubsetRandomSampler, SequentialSampler
import random
import torch
import numpy as np
import matplotlib.pyplot as plt
        



with open('files_test.txt') as f:
    ind_tmp = ['../SIDD_Medium_Srgb/Data/'+ line.rstrip('\n') for line in f]
    indices = [ind.split('.PNG')[0] + '/' for ind in ind_tmp]
    f.close()

dataset_path = '../SIDD_Medium_Srgb/Data/'




full_list=glob.glob(dataset_path + '*/')

ft_list=list(set(full_list)-set(indices))
test_list = list(set(indices))


ft_list_GT= [glob.glob(IM + '*GT_SRGB_010.PNG')[0]  for IM in ft_list]
ft_list_noisy= [glob.glob(IM + '*NOISY_SRGB_010.PNG')[0]  for IM in ft_list]

with open('FT_DATA_GT.txt', 'w') as f:
    for item in ft_list_GT:
        f.write("%s\n" % item)
        
with open('FT_DATA_NOISY.txt', 'w') as f:
    for item in ft_list_noisy:
        f.write("%s\n" % item)
        
        


test_list_GT= [glob.glob(IM + '*GT_SRGB_010.PNG')[0]  for IM in test_list]
test_list_noisy= [glob.glob(IM + '*NOISY_SRGB_010.PNG')[0]  for IM in test_list]

with open('TEST_DATA_GT.txt', 'w') as f:
    for item in test_list_GT:
        f.write("%s\n" % item)
        
with open('TEST_DATA_NOISY.txt', 'w') as f:
    for item in test_list_noisy:
        f.write("%s\n" % item)