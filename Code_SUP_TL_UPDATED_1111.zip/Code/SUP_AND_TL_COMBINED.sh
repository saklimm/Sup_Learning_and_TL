#!/bin/bash

#########################
# Global Parameters
######################### 

######### CHANGE DATASET


num_epochs=700

# LR used for supervised learning
sup_train_lr=0.0001 
# LR used for Fine Tuning

FT_LR=0.0001

# DONT CHANGE ANYTHING AFTER HERE

#########################
# Experiment 1 - 3 Poissonian - DnCNN
######################### 


experiment_name='3_Poissonian'
num_experments=\[3,0\]
network_type="DnCNN"


python3 Supervised_Learning.py $num_epochs $sup_train_lr $num_experments $network_type $experiment_name
python3 Sup_Learning_Test.py $experiment_name $network_type $sup_train_lr
python3 FT_and_Test.py $experiment_name $network_type $num_epochs $sup_train_lr $FT_LR



#########################
# Experiment 2 - 3 Poissonian - xDnCNN
######################### 


experiment_name='3_Poissonian'
num_experments=\[3,0\]
network_type="xDnCNN"


python3 Supervised_Learning.py $num_epochs $sup_train_lr $num_experments $network_type $experiment_name
python3 Sup_Learning_Test.py $experiment_name $network_type $sup_train_lr
python3 FT_and_Test.py $experiment_name $network_type $num_epochs $sup_train_lr $FT_LR



#########################
# Experiment 3 - 3 Gaussian - DnCNN
######################### 


experiment_name='3_Gaussian'
num_experments=\[0,3\]
network_type="DnCNN"


python3 Supervised_Learning.py $num_epochs $sup_train_lr $num_experments $network_type $experiment_name
python3 Sup_Learning_Test.py $experiment_name $network_type $sup_train_lr
python3 FT_and_Test.py $experiment_name $network_type $num_epochs $sup_train_lr $FT_LR



#########################
# Experiment 4 - 3 Gaussian - xDnCNN
######################### 


experiment_name='3_Gaussian'
num_experments=\[0,3\]
network_type="xDnCNN"



python3 Supervised_Learning.py $num_epochs $sup_train_lr $num_experments $network_type $experiment_name
python3 Sup_Learning_Test.py $experiment_name $network_type $sup_train_lr
python3 FT_and_Test.py $experiment_name $network_type $num_epochs $sup_train_lr $FT_LR






#########################
# Experiment 5 - 3_Poissonian_3_Gaussian - DnCNN
######################### 


experiment_name='3_Poissonian_3_Gaussian'
num_experments=\[3,3\]
network_type="DnCNN"


python3 Supervised_Learning.py $num_epochs $sup_train_lr $num_experments $network_type $experiment_name
python3 Sup_Learning_Test.py $experiment_name $network_type $sup_train_lr
python3 FT_and_Test.py $experiment_name $network_type $num_epochs $sup_train_lr $FT_LR



#########################
# Experiment 6 - 3_Poissonian_3_Gaussian - xDnCNN
######################### 


experiment_name='3_Poissonian_3_Gaussian'
num_experments=\[3,3\]
network_type="xDnCNN"



python3 Supervised_Learning.py $num_epochs $sup_train_lr $num_experments $network_type $experiment_name
python3 Sup_Learning_Test.py $experiment_name $network_type $sup_train_lr
python3 FT_and_Test.py $experiment_name $network_type $num_epochs $sup_train_lr $FT_LR











