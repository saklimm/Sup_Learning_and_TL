

import torch
from torch.utils.data.dataset import Dataset
import torch.nn as nn
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from torchvision import transforms
from PIL import Image
from random import sample
import os
from Generate_Tasks import *
from Network import *
import sys

from skimage.measure import compare_ssim, compare_psnr

import time

import numpy as np




def get_state_dict(experiment_folder,STEP):

    

    State_Dict_path  = experiment_folder + 'Training_Results/' +'State_Dicts/State_Dict_Step_' + str(STEP)
    
    return State_Dict_path



def SL_TEST(experiment_name,network_type,SUP_LEARNING_LR):
    
    if network_type == "DnCNN":
        model= DnCNN(image_channels=3)
    else:
        model= xDnCNN(image_channels=3)
    
    Sup_and_TL_Learning_LR=0.001
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    datasets_path = '../Dataset/'
    experiment_folder = '../Results_Folder/Sup_and_TL_Learning_LR='+SUP_LEARNING_LR+'/'+ experiment_name + '_' + network_type + '/'
    
    
    
    if not os.path.exists(experiment_folder + 'SUPERVISED_LEARNING_TEST/'):
        os.mkdir(experiment_folder + 'SUPERVISED_LEARNING_TEST/')
    
    
    
    STEPS = np.arange(10,501,10)
    
    PSNR_test = torch.zeros([3,len(STEPS)] )
    SSIM_test= torch.zeros([3,len(STEPS)] )
    crop_size=55
    test_loader = SSID_TEST_LOADER(crop_n=80).loader
    
    for step in STEPS:
    
        State_Dict_path = get_state_dict(experiment_folder, step )
        model.load_state_dict(torch.load(State_Dict_path))
        
        model.to(device)
        model.eval()
        
        PSNR_STEP = torch.Tensor()
        SSIM_STEP = torch.Tensor()
        
        with torch.no_grad():
            for noisy_image,truth in test_loader:
                
                # noisy_image,truth = iter( test_loader).next()
                noisy_image = noisy_image.reshape(-1,3,crop_size,crop_size)
                truth = truth.reshape(-1,3,crop_size,crop_size)
                
                denoised_imgs = model.forward(noisy_image)
                
                img_out = DENORMalize(denoised_imgs, 0.0, 255.0).cpu().detach().numpy().astype('uint8').transpose((0,2,3,1))
                img_GT =  DENORMalize(truth, 0.0, 255.0).cpu().detach().numpy().astype('uint8').transpose((0,2,3,1))
                
                #for k in range(img_out.shape[0]):
                
                psnr_out = torch.Tensor( [compare_psnr(img_out, img_GT)] )
                ssim_out = torch.Tensor( [compare_ssim(img_out, img_GT,multichannel=True)] )
            
                PSNR_STEP = torch.cat([PSNR_STEP,psnr_out])
                SSIM_STEP = torch.cat([SSIM_STEP,ssim_out])
            
        PSNR_test[:, int(step/10 -1)] = torch.Tensor([PSNR_STEP.max().item(),PSNR_STEP.min().item(),PSNR_STEP.mean().item()])
        SSIM_test[:,int(step/10 -1)] = torch.Tensor([SSIM_STEP.max().item(),SSIM_STEP.min().item(),SSIM_STEP.mean().item()])
        
        print("Experiment: ", experiment_name + '_' + network_type )
        print("Current Step: ", step)
        print("Current PSNR: ", PSNR_test[2,int(step/10 -1)])
        print("Current SSIM: ", SSIM_test[2,int(step/10 -1)])
        
    torch.save(PSNR_test, experiment_folder + 'SUPERVISED_LEARNING_TEST/PSNR_TEST')
    torch.save(SSIM_test, experiment_folder + 'SUPERVISED_LEARNING_TEST/SSIM_TEST')


if __name__ == "__main__":
    
    EXPERIMENT_NAME= sys.argv[1]
    NETWORK_TYPE= sys.argv[2]
    SUP_LEARNING_LR = str(sys.argv[3])
    SL_TEST(EXPERIMENT_NAME,NETWORK_TYPE,SUP_LEARNING_LR)
    
