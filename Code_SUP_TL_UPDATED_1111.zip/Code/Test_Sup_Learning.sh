#!/bin/bash




###########################
# Experiment 1
# 3 Poissonian DnCNN
###########################

experiment_name="3_Poissonian"
network_type="DnCNN"

#python3 Sup_Learning_Test.py $experiment_name $network_type



###########################
# Experiment 2
# 3 Gaussian DnCNN
###########################

experiment_name="3_Gaussian"
network_type="DnCNN"

python3 Sup_Learning_Test.py $experiment_name $network_type



###########################
# Experiment 3
# 3_Poissonian_3_Gaussian DnCNN
###########################

experiment_name="3_Poissonian_3_Gaussian"
network_type="DnCNN"

#python3 Sup_Learning_Test.py $experiment_name $network_type






###########################
# Experiment 4
# 3 Poissonian xDnCNN
###########################

experiment_name="3_Poissonian"
network_type="xDnCNN"

#python3 Sup_Learning_Test.py $experiment_name $network_type



###########################
# Experiment 5
# 3 Gaussian DnCNN
###########################

experiment_name="3_Gaussian"
network_type="xDnCNN"

#python3 Sup_Learning_Test.py $experiment_name $network_type



###########################
# Experiment 6
# 3_Poissonian_3_Gaussian DnCNN
###########################

experiment_name="3_Poissonian_3_Gaussian"
network_type="xDnCNN"

#python3 Sup_Learning_Test.py $experiment_name $network_type
